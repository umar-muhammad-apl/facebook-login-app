// Import Pushy Service Worker 1.0.8
importScripts('https://sdk.pushy.me/web/1.0.8/pushy-service-worker.js');